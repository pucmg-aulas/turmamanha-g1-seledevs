package br.com.javaParking.model;

public class ArrecadacaoModel {
    
}
